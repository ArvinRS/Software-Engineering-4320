<div><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQyEpImnaxtOdBO3GongSe3o3noc78GiA3BLA&usqp=CAU" width="300px" align="left"></div>

<br><br>
<br><br>
<br><br>

<div align="center">
  <h1>TNTech SAE Baja Sensor Network Project
    <br><br>
    <br><br>
  </h1>
</div>

<div align="center">
  <a href="#about">About</a> •
  <a href="#manual">User Manual</a> •
  <a href="#iterations">Iterations</a> •
  <a href="#risk_analysis">Risk Analysis</a> •
  <a href="#product_improvement">Product Improvement</a> •
  <a href="#data_collection">Data Collection</a> •
  <a href="#updating">Updating</a> •
  <a href="#features">Features</a>
</div>



<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>



# About
The goal of this project is to develop a network of sensors that collects and aggregates data into something that provides useful insights to the SAE Baja team. 

This inital goal was accomplished through the use Sensors, Arduinos, and a Raspberry Pi. 

The Ardiunos used the sensors to collect raw data during the duration of each test run. The Arduino would then transfer this raw data to the Raspberry Pi. The Raspberry Pi aggregates the data from both of the Ardiunos and calculates the desired data points. Once the test run is over, the Raspberry Pi will export the data in human-readable formats. 

### Team Lead: 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Paul Haines

### Developer and Software Design: 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Logan Gillum

### Data Aggregation: 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Arvin Sanchez | Peyton Whitefield 

### Hardware Design: 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Jalen Bowens | Gabriel Shanahan

### Stakeholders:  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Dr. William Brooksheer | Brandon Patel

### Team Coach:  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Eric Brown



<br><br>
<br><br>


# Manual

## Step 1: Attach Sensors
First begin by mounting the Hall Effect and Shock sensors to the Baja vehicle. 

## Step 2: Attach Arduinos
Once the sensors are mounted then you must place the Arduinos on the baja buggy. One will be located in the back of the Baja buggy and the other in the front. 

Once the Arduinos are secured connect the sensors to the Arduino via the wire connection ports labeled DS, PS, DH, and PH.
DS - Driver side Shock
PS - Passager side Shock
DH - Drive side Hall Effect
PH - Passanger side Hall Effect

## Step 3: Attach Raspberry Pi
Place the Raspberry Pi on the driver side between the seat and frame and secure.

Next, connect the Arduinos to the Raspberry Pi via USB ports.

## Step 4: Securing USB stick and powering on
Secure the USB stick used to store the data to the USB extded wire.

Inside the Raspberry Pi case the is a button controller to press in order for the power to bein powering on. Press this button and wait approximatly a minute before testing.

## Step 5: Testing
On the shell of the Raspberry Pi there is a switch to flip and begin recording data from the sensors and writeing them to a file.

Once the test is complete flip the switch in order to stop writing to a file.

## Step 6: Disconnect
Follow the previous instruction backwards starting at step 4 and working down to disconnect the system.


<br><br>


# Iterations

## Iteration 0
In iteration 0 there was a meeting with the client in order to understand what we had been assigned to complete.

Initial Scope was established to create a system for measuring Revolutions Per Minute (RPM) for each wheel and Shock Distance.
It was decided from the list of potential projects to put together a sensor system for the Baja buggy.

User stories were created in order to set a direction in which the team would work towards.

Research began into the parts needed in order to put together a sensor system.



<br><br>

## Iteration 1
Iteration 1 consisted of vasts amount of research into the various methods we could put together a sensor system.

Research consisted of compatibilty between Raspberry Pi and Ardiuno, how an Ardiuno functions, types of sensors for shocks, types of sensor for RPM, and compatibilty between Ardiuno and the sensors.

The team determined to use Hall Effect sensors to measure RPM as well as Potentiometers to find shock displacement.

Python was determined to be used as the primary language for the system driver, data aggregation, and data output.

Various measurements and observations were made to better understand methods and placement of sensors and cases upon the buggy.

Finalization of a buy list for parts needed for the senor system.

Finalizing a plan of action in regards to how we intended the system to function.


<br><br>
## Issues

The Issue that we faced in Iteration 1 was that the vehicle was not fully designed yet so it was hard to do testing and fittings to the vehicle. There is not really a solution to solving this issue. We tried our best to get good designs and mounts for the vehicle.

<br><br>

## Iteration 2
Iteration 2 was the first iteration of the Fall 2022 Semester.


We received the requested hardware at the beginning of Iteration 3. 
<div>
<img src="https://cdn.discordapp.com/attachments/384262232927764484/1021495977816883271/BuyList.jpg" width="400px" align="left">
<br><br>
<br><br>
<br><br>
</div>

### &nbsp; Hardware
```
Inventory:
  4 Linear Potentiometer Sensors
  12 Hall Effect Sensors
  2 Arduino UNO R3 Boards
  1 CanaKit Raspberry Pi 
  1 ANKER USB Power Bank
  1 25ft Bundle of Cable Protector
  1 Box of Cable Spools
  2 USB Cables [Male A:Male B 6.6ft]
  1 Box of small Neodynium Magnets
```

<br><br>
<br><br>
<br><br>

### `serialCom.py`

EventsPerTime is used to capture Wheel RPM. We initalize 4 of these functions to run per loop to capture all 4 wheels individually.

```
def EventsPerTimeH1():
    global RPM, thisTime, lastTime
    thisTime = time.time()
    RPM = (1/(thisTime - lastTime))*60
    lastTime = thisTime
    return(RPM)
```

The Arduino passes Comm data to the Raspberry Pi via Ascii code, so we have to accept the entire buffer into `serialDataF` and then sort out Driver/Passenger into `dataHall` manually. 

```
#Example of reading serial data from front Arduino
  serialDataF = front.readline()

#Creating array for sensor data 
  dataHall = [1, 1]

#Example of Hall Effect Driver Side Front Updater
  if dataHall[0] != oldData1:
      RPM1 = EventsPerTimeH1()
  if dataHall[0] == oldData1:
      print('Front Driver Side Wheel RPM = ', end ='')
      print(0, end = ' ')
      RPM1 = 0

#Storing data in array
  dataHall[0] = serialDataF[0]
  dataHall[1] = serialDataF[1]
```
<br><br>

## Issues

There were no issues for Iteration 2.

<br><br>

## Iteration 3
Iteration 3 consisted of implementing a new version of structuing for files being written too, and a script to run to capture data once the Ardiuno is powered on.

It also consisted on learning the 3D software tool to design the cases for the Ardiuno and the Raspberry Pi. We went with AutoCAD for its blueprint and 3D capabilities. With this the first prototype for the Raspberry Pi and Arduino case was developed. You can view the prototypes as drawings (DWG) in the folders that are labeled Pi and Arduino Case Documentation.


### `_systemDriver.py`

In version 2, we implemented an Object-Oriented Approach to structuring the software allowing us to link software objects with the real world objects that live on the buggy.   
  
Additionally, this adds the ability to scale with ease when additional sensors are added to the system.
```
#Example of Suspension Variable for Driver Front Suspension
  driverFront = suspension("Driver Side Front",shockVoltage)

#Example of setting RPM
  driverFront.wheelSensor.setRPM()

#Example of setting Distance from ride height
  driverFront.shockSensor.setDistance(shockVoltage)

```

The suspension object holds all of the sensor objects that are located on that corner of the suspension on the Buggy.

```
class suspension:
    def __init__(self, name, shockVoltage):
        # Constructor that sets inital suspension settings
        self.name = name
        self.shockSensor = shock(shockVoltage)
        self.wheelSensor = wheel()
```

Each Sensor has a corresponding object file that holds the functions for updating the data for that object.  

```
class shock:
    def __init__(self,shockVoltage):
        # Constructor that sets inital suspension settings
        self.rideHeight = self.shockPosition(shockVoltage)
        self.distancefromZero = 0
```

```
class wheel:
    def __init__(self):
        # Constructor that sets inital suspension settings
        self.timestamp = 0
        self.RPM = self.setRPM()
```


### `meshedSensors.io`

This setup function is the first thing to run when the Arduino gets power. 

```
  # This call starts reading from the sensors at 9600 reads per second. 
    Serial.begin(9600);

  # Example of Defining a Pin for Shock Inputs
    pinMode(Shock, INPUT );

  # Example of Defining a Pin for Hall Effect Input
    pinMode(HallEffect,INPUT);

```

This Loop function running constantly polls sensors while Ardiuno runs.

```
 # Example of handling Hall Effect Sensor Input
    int value_Hall = digitalRead(HallEffect);
    Serial.print(value_Hall);
      
 # Example of handling Shock Sensor Input
    int value_Shock = analogRead(Shock);
    Serial.println(value_Shock);
```
<br><br>

## Issues

Some of the issues faced with was learning the 3D software to design the cases and make the dimensions accurate. 

The way we solved this was by watching tutorials on AutoCAD and doing a trail and error method when something did not work to try it again by coming up with a different design and learning from the past ones.


<br><br>

## Iteration 4
Iteration 4  contained some major progress for the project. The cases for both the Arduinos and the Pi began to be deveopled. Also, progress on the mounts continued as the shock mounts where completed and development on the hall effect mounts continued. 

As the cases were being developed, the sensors and the boards were connected and soldered. The main idea was that the system needed to be modular, so that was kept in mind as we did the connections. Each sensor has its own specified inlet for each Arduino. Also, the system needed a button for starting and stopping tests, so that was added and soldered.

Finally, on the code side of things, the script for CSV writing were created. It essentially appends data to an array every sample and then when testing ends, saves to a file. After this, the code for graph making was created for future use with the csv. These were implemented into the code as well as some more formatting fixes.

### `_systemDriver.py`

```
	dataFrame = pd.DataFrame(columns=['RPM','SHOCK DISTANCE', 'TIME']) # create dataframe with RPM, Shock Distance, and time
	dataFrame.drop(dataFrame.index, inplace=True) 

	writer=pd.ExcelWriter(f'Vehicle_CSV.xlsx') # Establish writer to write to file named.

	dataFrame['RPM'] = passengerBack.wheelSensor.getRPMData()
	dataFrame['SHOCK DISTANCE'] = passengerBack.shockSensor.getDistanceData()
	dataFrame['TIME'] = passengerBack.shockSensor.getDistanceTime()
	dataFrame.to_excel(writer, sheet_name='REAR PASSENGER')
	passengerBack.resetData()

	writer.save()

```

In an example section of _systemDriver.py above, we implemented the Pandas library to create a dataFrame object to transfer RPM, SHOCK DISTANCE, and TIME values before calling an Excel writier.

For the graph representation of the data, we implemented Python's matplotlib library to create two 2-Dimensional graphs based on time.  

```
	fig,axs = plt.subplots(2)
  ...
  axs[0].plot(driverFD['TIME'],driverFD['RPM'], label = 'FD RPM' )
	axs[0].plot(driverFP['TIME'],driverFP['RPM'], label = 'FP RPM' )
	axs[0].plot(driverRD['TIME'],driverRD['RPM'], label = 'RD RPM' )
	axs[0].plot(driverRP['TIME'],driverRP['RPM'], label = 'RP RPM' )
```

In the figure above from the printGraph() function, a 2 dimensional graph would be created by plotting all four wheels' RPM data with the X-axis being TIME before saving the figure as a PDF document.

<br><br>

## Issues
Some of the issues faced with Iteration 4 was with the development and designing of the cases were how to get the dimensions correct so that the case would fit within the buggy and trying to design a case that would be resistant to water. 

This was solved by looking at water resistant cases that were online to get an understanding of how they were made and developed then taking that information and putting it into our design. This worked out pretty well as the cases are resistant to water. The dimension for the holes in the Arduino casing were hard to get as wires were changing and things couldn't just fit into the case without leaving a bit of extra room so it would fit but the dimensions are okay. 


<br><br>

## Iteration 5
Iteration 5 involved of mostly wrapping things up. The Pi and Arduino cases were completed and printed. Also, the Hall effect's mount design was completed and the first version was printed out. The first draft for the Senior Poster Design day was created and submitted.

Next, the code was bug-tested and fool-proofed. This was done by try/excepting error prone parts of the code, especially the serial read parts. The csv code was used to create graphs and save them to a pdf. After this, code was written to save both the csv and graphs so that they wouldn't overwrite old data. This was done by simply appending a timestamp to the file names.
<br><br>

## Issues
Some of the issues faced with Iteration 5 was 3D printing. There were a lot of re-prints that happended due to the material used for the cases and the 3D printers weren't always good at getting the right temperature so a lot of the parts bent or broke and even didn't print correctly a lot of the time. 

We solved this by just printing them again and again until the 3D printer got it right and the cases were to our specifications.

<br><br>


## Iteration 6
Iteration 6 was the final iteration where the team debugged the system.

Debugging consisted of various tests to deplete any errors that may occur on the system.

Iteration 6 also consisted of documenting information in regards to the progress we had made throughout the iterations.

Finally, the system was delivered to the client.

<br><br>

## Issues
One of the issues faced during Iteration 6 was the Raspberry Pi put a default user/password that wasn't clearing out.

This was solved by fixing the error in the code and clearing out the user/password.

<br><br>
<br><br>

## Risk_Analysis

-Map your assets
  
  - Network System: PI, Ardunios, Sensors
  - Data

-Identify security threats and vulnerabilities if  any

  - System Failure, Error from arduinos not being correctly plugged in.
  - Hardware Damage due to Testing, Vibrational or client mishaps.

-Determine and prioritize risks 

  - Data either becomes corrupted or isn't saved
  - Part of system is damaged which requires replacements

-Document the results and the remediation plan to mitigate the risks

  - System ouputs error text so that user knows when system startup has failed i.e. arduinos not plugged in correctly.
  - System is modular to minimize damage to parts and components are secured in cases.

<br><br>

## Product_Improvement

-Quality over quantity. Does your end product pass all quality testing with respect to code and functionality?
 
 - The code passes the quality check. Hardware wise, there could be some work with the final designing. These include the cases, wiring, mounting

-Has the end product been developed according to the client-approved specification?
  
  - The end product has been developed according to the client's specification. Our MVP was to develop a system to read and write RPM and Shock values which we accomplished.

-What features make your product outstanding and in-demand? 
  
  - The product is modular and designed ot be upgradable.

-What benefits do consumers gain when using the product?
  
  - They are able to get high sample rate data for presice testing. This allows for more fine tuning on the buggy for better performance.

-What new features and functions can you add to the product to make it more effective? 
  
  - The network is fully upgradable with multiple slots for new sensors. These could be any sensor the client might want to add to the system to furth get details for performance enhancments.

<br><br>

# Data_Collection
-How is the data collected?
  - The data is collected from the sensors constantly once the system is powered on by the Aurduinos via the following code. Once the switch is flipped to record data on the exterior of the Raspberry Pi case then the data will be allowed to flow to the Raspberry Pi.
```
 # Example of handling Hall Effect Sensor Input
    int value_Hall = digitalRead(HallEffect);
    Serial.print(value_Hall);
      
 # Example of handling Shock Sensor Input
    int value_Shock = analogRead(Shock);
    Serial.println(value_Shock);
```

-How is the data stored?
  - The data is stored on a USB stick once it is inserted into the USB extendor in the Raspberry Pi case. Once the switch is flipped it uses the USB script to write to the stick.

-What kind of data is stored?
  - The data stored within the stick consists of a spreadsheet with the information regarding the the sesnor outputs. The data is then read and uses Pandas for Python, which turns the data into graphs giving results based on the time and change in either RPM or Shock impact.

<br><br>

# Updating
This section is dedicated to helping the next group to take over this project.


### `SSH into the Raspberry Pi`
In order to log into the Raspberry Pi, you'll need a couple of things. 

Firstly, You will need to be on EagleNet to be able to SSH into the Pi. 

Next, download the following "Required Programs".
```
Reqiured Programs [Windows]:
* Putty with PuttyGen
* WinSCP or any other File-Transfer Program
```
```

Optional Programs:
* RealVNC (Interact through Desktop interface)
```
Then, you will need to supply the Raspberry Pi some power.
* Insert Photo of power button here

Next, Open Putty, input the following information, and hit "Open".
If you are using another connection software, enter the following IP address and login credentials.
```
IP Address: 10.129.202.168
```

This will prompt you to sign into the Raspberry Pi. Credentials are below.
```
Username: pi
Password: raspberry
```














