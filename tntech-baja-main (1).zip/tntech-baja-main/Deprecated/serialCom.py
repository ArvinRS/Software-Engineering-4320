import serial
import string
import time

#Here /dev/ttyUSB2 is used
#It can be different in your case like /dev/ttyUSB0, /dev/ttyUSB1 etc.
#opening serial ports
front = serial.Serial('COM3', 9600)
back = serial.Serial('COM4', 9600)


#Initializng variables for wheel speeds
#Front Driver
lastTime = time.time()
thisTime = time.time()
RPM = 0
oldData1 = 49
#Front Passenger
lastTime2 = time.time()
thisTime2 = time.time()
RPM2 = 0
oldData2 = 49
#Back Driver
lastTime3 = time.time()
thisTime3 = time.time()
RPM3 = 0
oldData3 = 49
#Back Passenger
lastTime4 = time.time()
thisTime4 = time.time()
RPM4 = 0
oldData4 = 49


#Functions
#Front Side----------------------------
#Front Driver
def EventsPerTimeH1():
    global RPM, thisTime, lastTime
    thisTime = time.time()
    RPM = (1/(thisTime - lastTime))*60
    print('Front Driver Side Wheel RPM = ', end ='')
    print(RPM, end = ' ')
    lastTime = thisTime
    return(RPM)
#Front Passenger
def EventsPerTimeH2():
    global RPM2, thisTime2, lastTime2
    thisTime2 = time.time()
    RPM2 = (1/(thisTime2 - lastTime2))*60
    print('Front Passenger Side Wheel RPM = ', end ='')
    print(RPM2)
    lastTime2 = thisTime2
    return(RPM2)

#Back Side-----------------------------
#Back Driver
def EventsPerTimeH3():
    global RPM3, thisTime3, lastTime3
    thisTime3 = time.time()
    RPM3 = (1/(thisTime3 - lastTime3))*60
    print('Back Driver Side Wheel RPM = ', end ='')
    print(RPM3, end = ' ')
    lastTime3 = thisTime3
    return(RPM3) 
#Back Passenger
def EventsPerTimeH4():
    global RPM4, thisTime4, lastTime4
    thisTime4 = time.time()
    RPM4 = (1/(thisTime4 - lastTime4))*60
    print('Back Passenger Side Wheel RPM = ', end ='')
    print(RPM4)
    lastTime4 = thisTime4
    return(RPM4)      

#While loop for recieving data from Ardinos and formating them
while True:
    #Reading front serial
    serialDataF = front.readline()
    serialDataF2 = front.readline()
    serialDataF3 = front.readline()
    #Reading back serial
    serialDataB = back.readline()
    serialDataB2 = back.readline()
    serialDataB3 = back.readline()

    #Creating array for sensor data 
    dataHall = [1, 1]
    dataHall2 = [1, 1]
    #Storing data in array
    dataHall[0] = serialDataF[0]
    dataHall[1] = serialDataF[1]

    dataHall2[0] = serialDataB[0]
    dataHall2[1] = serialDataB[1]

    #Reseting Totals
    #shockTotali is the integer version of shockTotala later on
    shockTotal1i = 0
    shockTotal2i = 0
    shockTotal3i = 0
    shockTotal4i = 0
    #Calculated RPM values
    RPM1 = 0
    RPM2 = 0
    RPM3 = 0
    RPM4 = 0
    print('==========Wheels==========')
    #Hall Effect Driver Side Front---------------------------
    if dataHall[0] != oldData1:
        RPM1 = EventsPerTimeH1()
        
    if dataHall[0] == oldData1:
        print('Front Driver Side Wheel RPM = ', end ='')
        print(0, end = ' ')
        RPM1 = 0
    #Hall Effect Passenger Side Front------------------------
    if dataHall[1] != oldData2:
        RMP2 = EventsPerTimeH2()
    if dataHall[1] == oldData2:
        print('Front Passenger Side Wheel RPM = ', end =' ')
        print(0)
        RPM2 = 0

    #Hall Effect Driver Side Back---------------------------

    if dataHall2[0] != oldData3:
        RMP3 = EventsPerTimeH3()
    if dataHall2[0] == oldData3:
        print('Back Driver Side Wheel RPM = ', end ='')
        print(0, end = ' ')
        RPM3 = 0
    #Hall Effect Passenger Side Back------------------------
    if dataHall2[1] != oldData4:
        RMP4 = EventsPerTimeH4()
    if dataHall2[1] == oldData4:
        print('Back Driver Side Wheel RPM = ', end ='')
        print(0)
        RPM4 = 0

    print('==========Shocks==========')
    #Start Shock 1 Driver Side -----------------------------
    i = len(serialDataF2) -3
    j = len(serialDataF2) -2
    shockTotal1a = [0,0,0,0]

    #Populating array with ascii values of each number in the shock data
    while i != -1:
        shockTotal1a[j] = chr(serialDataF2[i])
        i = i-1
        j = j-1

    #New lengths for the while
    i = len(shockTotal1a) -1
    j = 1

    #Converting the ascii array to an integer number
    while i != -1:
        shockTotal1i = shockTotal1i + int(shockTotal1a[i])*j
        i = i-1
        j = j*10
        
    print('Front Shock Driver Side Voltage = ', end='')
    print(shockTotal1i, end=' ')
    #End Shock Driver Side Front -------------------------------

    #Start Shock Passenger  Front ------------------------------
    i = len(serialDataF3) -3
    j = len(serialDataF3) -2
    shockTotal2a = [0,0,0,0]

    #Populating array with ascii values of each number in the shock data
    while i != -1:
        shockTotal2a[j] = chr(serialDataF3[i])
        i = i-1
        j = j-1

    #New lengths for the while
    i = len(shockTotal2a) -1
    j = 1

    #Converting the ascii array to an integer number
    while i != -1:
        shockTotal2i = shockTotal2i + int(shockTotal2a[i])*j
        i = i-1
        j = j*10

    print('Front Shock Passenger Side Voltage = ', end ='')
    print(shockTotal2i)
    #End Shock Passenger Front -------------------------------

    #Start Shock Driver Back ---------------------------------
    i = len(serialDataB2) -3
    j = len(serialDataB2) -2
    shockTotal3a = [0,0,0,0]

    #Populating array with ascii values of each number in the shock data
    while i != -1:
        shockTotal3a[j] = chr(serialDataB2[i])
        i = i-1
        j = j-1

    #New lengths for the while
    i = len(shockTotal3a) -1
    j = 1

    #Converting the ascii array to an integer number
    while i != -1:
        shockTotal3i = shockTotal3i + int(shockTotal3a[i])*j
        i = i-1
        j = j*10
        
    print('Back Shock Driver Side Voltage = ', end='')
    print(shockTotal3i, end=' ')
    #End Shock Driver Back -----------------------------------

    #Start Shock Passenger Back ------------------------------
    i = len(serialDataB3) -3
    j = len(serialDataB3) -2
    shockTotal4a = [0,0,0,0]

    #Populating array with ascii values of each number in the shock data
    while i != -1:
        shockTotal4a[j] = chr(serialDataB3[i])
        i = i-1
        j = j-1

    #New lengths for the while
    i = len(shockTotal4a) -1
    j = 1

    #Converting the ascii array to an integer number
    while i != -1:
        shockTotal4i = shockTotal4i + int(shockTotal4a[i])*j
        i = i-1
        j = j*10

    print('Back Shock Passenger Side Voltage = ', end ='')
    print(shockTotal4i)
    #End Shock Passenger Back --------------------------------

    oldData1 = dataHall[0]
    oldData2 = dataHall[1]
    oldData3 = dataHall2[0]
    oldData4 = dataHall2[1]
