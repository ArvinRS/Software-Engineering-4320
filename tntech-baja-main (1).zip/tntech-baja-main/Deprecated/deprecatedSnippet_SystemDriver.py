      #Potentially Depricated Code
      while False:

        #-------------------------------------------Front-------------------------------------------

        #----------------------Driver---------------------
    
        #Driver Front Hall Effect
        if dataFHE[0] != oldDataHE[0]:
          driverFront.wheelSensor.setRPM()
          print(driverFront.wheelSensor.getRPM())
        else:
          print(driverFront.wheelSensor.getRPM())

        #Driver Front Shock
          driverFront.shockSensor.setDistance(serialDataFDS)
          print(driverFront.shockSensor.getDistance())

        #----------------------Passenger -------------------
          
        #Passenger Front Hall Effect
        if dataFHE[1] != oldDataHE[1]:
          passengerFront.wheelSensor.setRPM()
          print(passengerFront.wheelSensor.getRPM())
        else:
          print(passengerFront.wheelSensor.getRPM())

        #Passenger Front Shock
        passengerFront.shockSensor.setDistance(serialDataFPS)
        print(passengerFront.shockSensor.getDistance())
          
        #-------------------------------------------------------------------------------------------
      
        #-------------------------------------------Back--------------------------------------------

        #----------------------Driver---------------------
          
        #Driver Back Hall Effect
        if dataBHE[0] != oldDataHE[2]:
          driverBack.wheelSensor.setRPM()
          print(driverBack.wheelSensor.getRPM())
        else:
          print(driverBack.wheelSensor.getRPM())

        #Driver Back Shock
        driverBack.shockSensor.setDistance(serialDataBDS)
        print(driverBack.shockSensor.getDistance())       

        #----------------------Passenger -------------------

        #Passenger Back Hall Effect
        if dataBHE[1] != oldDataHE[3]:
          passengerBack.wheelSensor.setRPM()
          print(passengerBack.wheelSensor.getRPM())
        else:
          print(passengerBack.wheelSensor.getRPM())
      
        #Passenger Back Shock
        passengerBack.shockSensor.setDistance(serialDataBPS)
        print(passengerBack.shockSensor.getDistance())      

        #-------------------------------------------------------------------------------------------
        
