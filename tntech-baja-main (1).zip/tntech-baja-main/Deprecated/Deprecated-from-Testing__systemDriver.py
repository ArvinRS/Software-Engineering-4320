# 
#  File:     _systemDriver.py
#  Imports:  suspension.py | wheel.py | shock.py
#  Purpose:  SystemDriver for TnTech Baja Sensor Network
#  Date:     09/20/2022
#  Org:      Software Engineering Baja Team
#  Author:   Logan Gillum, Paul Haines
#  Ref:      serialCom.py
#           

#Already on PI
from pickle import NONE
import serial
import time
import RPi.GPIO as GPIO
import pandas as pd
pd.options.mode.chained_assignment=None

from os import system
from suspension import suspension

#Adding a switch read at pin 16 on the Raspberry PI
BUTTON_PIN = 16
GPIO.setmode(GPIO.BCM)
GPIO.setup(BUTTON_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)

#Here /dev/ttyACM0 and /dev/ttyACM1 is used for the Pi
#It can be different in your case like /dev/ttyUSB0, /dev/ttyUSB1 etc.
#For testing in windows, the serial ports would be formatted like 'COM3' or 'COM4'
#opening serial ports
front = serial.Serial('/dev/ttyACM0', 9600)
back = serial.Serial('/dev/ttyACM1', 9600)

def main():

  #Initializing the Serial Data Holders
  serialDataFDHE = NONE
  serialDataFPHE = NONE
  serialDataFDS = NONE
  serialDataFPS = NONE

  serialDataBDHE = NONE
  serialDataBPHE = NONE
  serialDataBDS = NONE
  serialDataBPS = NONE

  #Validation Loop for front of the buggy
  buffer = 1
  while buffer==1:
    count = 0
    k = 0
    while k < 4:
      temp = front.readline()
      if 'A' in chr(temp[0]):
        serialDataFDHE = temp
        count=count+1
      if 'B' in chr(temp[0]):
        serialDataFPHE = temp
        count=count+1
      if 'C' in chr(temp[0]):
        serialDataFDS = temp
        count=count+1
      if 'D' in chr(temp[0]):
        serialDataFPS = temp
        count=count+1
      else:
        pass
      k=k+1

    #Validation Loop for the back of the buggy
    l = 0
    while l < 4:
      temp = front.readline()
      if 'A' in chr(temp[0]):
        serialDataBDHE = temp
        count=count+1
      if 'B' in chr(temp[0]):
        serialDataBPHE = temp
        count=count+1
      if 'C' in chr(temp[0]):
        serialDataBDS = temp
        count=count+1
      if 'D' in chr(temp[0]):
        serialDataBPS = temp
        count=count+1
      else:
        pass
      l=l+1

      if count != 8:
        buffer = 1
      else:
        buffer = 0
  
  #Establish Suspension Variables for each corner
  driverFront = suspension("Driver Side Front",serialDataFDS)
  passengerFront = suspension("Passenger Side Front",serialDataFPS)

  driverBack = suspension("Driver Side Back",serialDataBDS)
  passengerBack = suspension("Passenger Side Back",serialDataBPS)
  i = 0
  #Misc Variables
  oldDataHE = [49,49,49,49]
  
  while True:
      FDW = []
      FDS = []
      FPW = []
      FPS = []
      RDW = []
      RDS = []
      RPW = []
      RPS = []
      dataFrame = pd.DataFrame(columns=['RPM','SHOCK DISTANCE'])
      dataFrame.drop(dataFrame.index, inplace=True)
      
      #While loop for when testing is started. IE. Switch is on
      #If need to test without swtich just change the condition to true
      while GPIO.input(BUTTON_PIN) == GPIO.LOW:

          #Read in Front 
          j = 0
          z = 0

          #Read Front
          while j < 4:
            temp = front.readline()
            if 'A' in chr(temp[0]):
              serialDataFDHE = temp
            if 'B' in chr(temp[0]):
              serialDataFPHE = temp
            if 'C' in chr(temp[0]):
              serialDataFDS = temp
            if 'D' in chr(temp[0]):
              serialDataFPS = temp
            j=j+1
          
          #Read Back
          while z < 4:
            temp = front.readline()
            if 'A' in chr(temp[0]):
              serialDataBDHE = temp
            if 'B' in chr(temp[0]):
              serialDataBPHE = temp
            if 'C' in chr(temp[0]):
              serialDataBDS = temp
            if 'D' in chr(temp[0]):
              serialDataBPS = temp
            z=z+1


          dataFHE = [1,1]
          dataBHE = [1,1]

          #Set SerialData to Data Array
          dataFHE[0] = serialDataFDHE[1]
          dataFHE[1] = serialDataFPHE[1]
          dataBHE[0] = serialDataBDHE[1]
          dataBHE[1] = serialDataBPHE[1]

          #Update Values
          
          #Driver Front Hall Effect
          if dataFHE[0] != oldDataHE[0]:
            driverFront.wheelSensor.setRPM()
          if dataFHE[0] == oldDataHE[0]:
            driverFront.wheelSensor.RPM = 0
            
          #Passenger Front Hall Effect
          if dataFHE[1] != oldDataHE[1]:
            passengerFront.wheelSensor.setRPM()
          if dataFHE[1] == oldDataHE[1]:
            passengerFront.wheelSensor.RPM = 0
            
          #Driver Back Hall Effect  
          if dataBHE[0] != oldDataHE[2]:
            driverBack.wheelSensor.setRPM()        
          if dataBHE[0] == oldDataHE[2]:
            driverBack.wheelSensor.RPM = 0      
            
          #Passenger Back Hall Effect
          if dataBHE[1] != oldDataHE[3]:
            passengerBack.wheelSensor.setRPM()
          if dataBHE[1] == oldDataHE[3]:
            passengerBack.wheelSensor.RPM = 0  

          driverFront.shockSensor.setDistance(serialDataFDS)
          driverBack.shockSensor.setDistance(serialDataBDS)
          passengerFront.shockSensor.setDistance(serialDataFPS)
          passengerBack.shockSensor.setDistance(serialDataBPS)
            
            
          #Print Suspension Stats
          #Something is messing up the program in here, commented it out and it works now
          driverFront.printSuspensionStats()
          print('\n')
          passengerFront.printSuspensionStats()
          print('\n')
          driverBack.printSuspensionStats()
          print('\n')
          passengerBack.printSuspensionStats()
          print("Loop")
          # system("cls")
            
          #Print testing
          # driverFront.wheelSensor.printRPM()
          # passengerFront.wheelSensor.printRPM()
          # driverBack.wheelSensor.printRPM()
          # passengerBack.wheelSensor.printRPM()
          # print(" ")
          FDW.append(driverFront.wheelSensor.getRPM())
          FDS.append(driverFront.shockSensor.getDistance())
          FPW.append(passengerFront.wheelSensor.getRPM())
          FPS.append(passengerFront.shockSensor.getDistance())
          RDW.append(driverBack.wheelSensor.getRPM())
          RDS.append(driverBack.shockSensor.getDistance())
          RPW.append(passengerBack.wheelSensor.getRPM())
          RPS.append(passengerBack.shockSensor.getDistance()) 


          #Set current data to old data
          oldDataHE[0] = dataFHE[0]
          oldDataHE[1] = dataFHE[1]
          oldDataHE[2] = dataBHE[0]
          oldDataHE[3] = dataBHE[1]
          i=1

        #Write statements go here, like the csv Write
      if i == 1:
          print("Write statements")
          writer=pd.ExcelWriter('Vehicle_Data.xlsx')
          
          dataFrame['RPM'] = FDW
          dataFrame['SHOCK DISTANCE'] = FDS
          print(dataFrame['RPM'])
          dataFrame.to_excel(writer, sheet_name='FRONT DRIVER')
          
          dataFrame['RPM'] = FPW
          dataFrame['SHOCK DISTANCE'] = FPS
          dataFrame.to_excel(writer, sheet_name='FRONT PASSENGER')
          
          dataFrame['RPM'] = RDW
          dataFrame['SHOCK DISTANCE'] = RDS
          dataFrame.to_excel(writer, sheet_name='REAR DRIVER')
          
          dataFrame['RPM'] = RPW
          dataFrame['SHOCK DISTANCE'] = RPS
          dataFrame.to_excel(writer, sheet_name='REAR PASSENGER')
          writer.save()

          
        #While loop to pause script when button when not testing. IE. Switch turned off
      while GPIO.input(BUTTON_PIN) == GPIO.HIGH:
          pass

    
if __name__ == "__main__":
    main()
