# 
#  File:     shock.py
#  Purpose:  shock object for suspension object
#  Date:     09/20/2022
#  Org:      Software Engineering Baja Team
#  Author:   Logan Gillum, Paul Haines
#       

from types import NoneType
import serial

class shock:
  #-------------------------------------------Worker Functions-------------------------------------------
  
    def __init__(self,SD):
        # Constructor 
        # Sets inital suspension settings
        self.rideHeight = self.shockPosition(SD)
        self.distancefromZero = 0

    def shockPosition(self,serialData):

      i = serialData.decode('utf-8')
      
      if "C" in i:
        return int(i[1:])
      if "D" in i:
        return int(i[1:])

      # # return distance

  #-------------------------------------------Access Functions-------------------------------------------

    # Set Shock Travel Variable
    def setDistance(self, comm):
        self.distancefromZero = self.shockPosition(comm) - self.rideHeight

    # Get Shock Travel Voltage
    def getVoltage(self):
        return self.distancefromZero
      
    # Get Shock Travel Variable in Millimeters.
    def getDistance(self):
        return self.distancefromZero / 5.115
      
    def printRideHeight(self):
      print("Ride height [{0}]".format(self.distancefromZero), sep='\n', end=' ', flush=True)

  #------------------------------------------------------------------------------------------------------


 
# Driver Code Examples
#Rodger = Dog("pug")
#Rodger.setColor("brown")
#print(Rodger.getColor())
