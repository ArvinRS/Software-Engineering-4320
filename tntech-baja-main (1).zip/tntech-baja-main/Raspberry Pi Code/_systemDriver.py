# 
#  File:     _systemDriver.py
#  Imports:  suspension.py | wheel.py | shock.py
#  Purpose:  SystemDriver for TnTech Baja Sensor Network
#  Date:     10/15/2022
#  Org:      Software Engineering Baja Team
#  Author:   Logan Gillum, Paul Haines, Arvin Sanchez
#  Ref:      serialCom.py
#           

# Import Section #
import os # Operating System controls
import serial # Pyserial for reading from the serial bus on the Pi
import time # Python Time for timestamps
from pathlib import Path # Python Path function for file creation
from suspension import suspension # Suspension container class that holds all sensors on a suspension
import RPi.GPIO as GPIO # Needs to be pip onto the PI
import pandas as pd # Pandas for Dataframes and CSV 
import matplotlib.pyplot as plt # Plotting for Graphing CSV Data


# Dataframe alterations
pd.options.mode.chained_assignment=None

BUTTON_PIN = 16 # Adding a switch read at pin 16 on the Raspberry PI
GPIO.setmode(GPIO.BCM)
GPIO.setup(BUTTON_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)


def main():


	# Serial Section
	front = serial.Serial('/dev/ttyACM0', 9600) # Opening front serial port
	back = serial.Serial('/dev/ttyACM1', 9600) # Opening back serial port
		# Here /dev/ttyACM0 and /dev/ttyACM1 is used for the Pi
		# It can be different in your case like /dev/ttyUSB0, /dev/ttyUSB1 etc.
		# For testing in windows, the serial ports would be formatted like 'COM3' or 'COM4' 

	trashValue = front.readline() # Read Trash Value ( May not be needed, but just for data sake. )

	# Intial serialReads for instatiating sensor objects.
	# calls serialRead function and stores return into Variables
	# Parameters = line letter and serial port
	# Line letter is used for syncing serialRead to specific line in serial bus
	driverFrontHallEffect = serialRead('A', front)
	passengerFrontHallEffect = serialRead('B', front)
	driverFrontShock = serialRead('C', front)
	passengerFrontShock = serialRead('D', front)
	driverBackHallEffect = serialRead('A', back)
	passengerBackHallEffect = serialRead('B', back)
	driverBackShock = serialRead('C', back)
	passengerBackShock = serialRead('D', back)

	# Establish Suspension Variables for each corner
	# calls suspension constructor and stores returned object into Variables
	# Parameters = Suspension object name and corresponding serialRead variable
	driverFront = suspension("Driver Side Front", driverFrontShock)
	passengerFront = suspension("Passenger Side Front", passengerFrontShock)
	driverBack = suspension("Driver Side Back", driverBackShock)
	passengerBack = suspension("Passenger Side Back", passengerBackShock)

	# Misc Variables
	oldDataHE = [49,49,49,49] # OldDataHE is for comparing last run data to current run data for checks
	hasData = 0 # Boolean for saving data if atleast one run has been complete
	timer = [0,0,0,0] # If second has passed, set RPM to zero. 
	data_run = 1 # Data variable to track # of runs in a given test session

	while True:

		# While loop for when testing is started. IE. Switch is on
		# If need to test without swtich just change the condition to true
		while GPIO.input(BUTTON_PIN) == GPIO.LOW:

			# Iterative serialReads for updating sensor data
			# calls serialRead function and stores return into Variables
			# Parameters = line letter and serial port
			# Line letter is used for syncing serialRead to specific line in serial bus
			driverFrontHallEffect = serialRead("A", front)
			passengerFrontHallEffect = serialRead('B', front)
			driverFrontShock = serialRead('C', front)
			passengerFrontShock = serialRead('D', front)
			driverBackHallEffect = serialRead("A", back)
			passengerBackHallEffect = serialRead('B', back)
			driverBackShock = serialRead('C', back)
			passengerBackShock = serialRead('D', back)

			# Update driver front hall effect
			# If current data does not equal to last data, update RPM. 
			# else if current data equals last data and current time minus last time greater than 0 or current time minus last time less than zero, set RPM to zero.
			# This should be converted to a function
			if driverFrontHallEffect != oldDataHE[0]:
				driverFront.wheelSensor.setRPM()
				timer[0] = time.localtime().tm_sec
			elif driverFrontHallEffect == oldDataHE[0] and (time.localtime().tm_sec - timer[0]) > 0 or (time.localtime().tm_sec - timer[0]) < 0:
				driverFront.wheelSensor.RPM = 0

			# Update passenger front hall effect
			# If current data does not equal to last data, update RPM. 
			# else if current data equals last data and current time minus last time greater than 0 or current time minus last time less than zero, set RPM to zero.
			# This should be converted to a function
			if passengerFrontHallEffect != oldDataHE[1]:
				passengerFront.wheelSensor.setRPM()
				timer[1] = time.localtime().tm_sec
			elif passengerFrontHallEffect == oldDataHE[1] and (time.localtime().tm_sec - timer[1]) >0 or (time.localtime().tm_sec - timer[1]) < 0:
				passengerFront.wheelSensor.RPM = 0

			# Update driver back hall effect  
			# If current data does not equal to last data, update RPM. 
			# else if current data equals last data and current time minus last time greater than 0 or current time minus last time less than zero, set RPM to zero.
			# This should be converted to a function
			if driverBackHallEffect != oldDataHE[2]:
				driverBack.wheelSensor.setRPM()
				timer[2] = time.localtime().tm_sec        
			elif driverBackHallEffect == oldDataHE[2] and (time.localtime().tm_sec - timer[2]) >0 or (time.localtime().tm_sec - timer[2]) < 0:
				driverBack.wheelSensor.RPM = 0

			# Update passenger back hall effect
			# If current data does not equal to last data, update RPM. 
			# else if current data equals last data and current time minus last time greater than 0 or current time minus last time less than zero, set RPM to zero.
			# This should be converted to a function
			if passengerBackHallEffect != oldDataHE[3]:
				passengerBack.wheelSensor.setRPM()
				timer[3] = time.localtime().tm_sec
			elif passengerBackHallEffect == oldDataHE[3] and (time.localtime().tm_sec - timer[3]) >0 or (time.localtime().tm_sec - timer[3]) < 0:
				passengerBack.wheelSensor.RPM = 0 

			# Update shock sensor data
			# Calls setDistance function from the shockSensors object nested in each suspension
			# Should convert to nested call in suspension object instead of accessing sensor object directly.
			driverFront.shockSensor.setDistance(driverFrontShock)
			driverBack.shockSensor.setDistance(driverBackShock)
			passengerFront.shockSensor.setDistance(passengerFrontShock)
			passengerBack.shockSensor.setDistance(passengerBackShock)

			# Append updated data to object list
			# Calls append data in suspension containerclass to append sensor data to each sensor objects internal list. 
			driverFront.appendData()
			driverBack.appendData()
			passengerFront.appendData()
			passengerBack.appendData()

			# Set current iteration data to old data for next compare
			oldDataHE[0] = driverFrontHallEffect
			oldDataHE[1] = passengerFrontHallEffect
			oldDataHE[2] = driverBackHallEffect
			oldDataHE[3] = passengerBackHallEffect

			# Set hasData to 1 so that it will save run
			hasData = 1

		# Data Export Block
		for x in range(hasData):
			# Put data export functions here so that they will be run after the switch gets turned off.
			# This block runs if one run has been completed above and hasData = 1
			# Currently, export functions are CSV and Graphing
			printCSV( driverFront, passengerFront, driverBack, passengerBack )
			printGraph()


		#While loop to pause script when button when not testing. IE. Switch turned off.
		while GPIO.input(BUTTON_PIN) == GPIO.HIGH:

			hasData = 0 # Set hasData to zero so that next run will be captured if it is completed. 
			
			stringTime = str(time.localtime().tm_mon) + '-' + str(time.localtime().tm_mday) + '-' + str(time.localtime().tm_year)+ ' ' + str(time.localtime().tm_hour) + ';' + str(time.localtime().tm_min) + ';' + str(time.localtime().tm_sec)
			#Below needs to be changed to potential usb path.
			stringDest = r"/media/pi/ESD-USB/data"
			stringDest2 = r"/media/pi/ESD-USB/graph"
			dest = os.path.join(stringDest, stringTime)
			dest2 = os.path.join(stringDest2, stringTime)
			dest = dest+r".xlsx"
			dest2 = dest2+r".pdf"
			src = "/home/pi/_Sensor_Network/Testing2/tntech-baja-UI-002_GraphCSV-Integration-Raspberry Pi Code/Raspberry Pi Code/Vehicle_CSV.xlsx"
			src2 = "/home/pi/_Sensor_Network/Testing2/tntech-baja-UI-002_GraphCSV-Integration-Raspberry Pi Code/Raspberry Pi Code/Vehicle_Graph.pdf"

			try:
				shutil.copy(src,dest)
			except:
				pass
			else:
				os.remove(src)
			try:
				shutil.copy(src2,dest2)
			except:
				pass
			else:
				os.remove(src2)


def serialRead(letter,serial):
	# This function returns line if letter is a substring.
	# Input: Byte Data { b'A01'\n } 
	# Output: Int { 1 }

	# Dirty checks with Try/Except. Should not be resource intensive as it should only miss a total of 3 times before hitting.
	try:
		line = serial.readline().decode('utf-8')
	except:
		return serialRead(letter,serial)


	if letter in line:
		try:
			return int(line[1:])
		except:
			serialRead(letter,serial)
	else:
		return serialRead(letter,serial)


def printCSV( driverFront, passengerFront, driverBack, passengerBack ):
	# Function prints Sensor object lists to a CSV file. 
	# Input: driverFront, passengerFront, driverBack, passengerBack 
	# Output: Nothing in the system, but outputs CSV file to specified path

	# Data Frame
	dataFrame = pd.DataFrame(columns=['RPM','SHOCK DISTANCE', 'TIME']) # create dataframe with RPM, Shock Distance, and time
	dataFrame.drop(dataFrame.index, inplace=True) 

	print("Write statements")
	writer=pd.ExcelWriter(f'Vehicle_CSV.xlsx') # Establish writer to write to file named.

	# Update the dataframes with sensor object data
	# This should be made into a function that accepts a single suspension object.

	dataFrame['RPM'] = driverFront.wheelSensor.getRPMData()
	dataFrame['SHOCK DISTANCE'] = driverFront.shockSensor.getDistanceData()
	dataFrame['TIME'] = driverFront.shockSensor.getDistanceTime()
	print(dataFrame['RPM'])
	dataFrame.to_excel(writer, sheet_name='FRONT DRIVER')
	driverFront.resetData()

	dataFrame['RPM'] = passengerFront.wheelSensor.getRPMData()
	dataFrame['SHOCK DISTANCE'] = passengerFront.shockSensor.getDistanceData()
	dataFrame['TIME'] = passengerFront.shockSensor.getDistanceTime()
	dataFrame.to_excel(writer, sheet_name='FRONT PASSENGER')
	passengerFront.resetData()

	dataFrame['RPM'] = driverBack.wheelSensor.getRPMData()
	dataFrame['SHOCK DISTANCE'] = driverBack.shockSensor.getDistanceData()
	dataFrame['TIME'] = driverBack.shockSensor.getDistanceTime()
	dataFrame.to_excel(writer, sheet_name='REAR DRIVER')
	driverBack.resetData()

	dataFrame['RPM'] = passengerBack.wheelSensor.getRPMData()
	dataFrame['SHOCK DISTANCE'] = passengerBack.shockSensor.getDistanceData()
	dataFrame['TIME'] = passengerBack.shockSensor.getDistanceTime()
	dataFrame.to_excel(writer, sheet_name='REAR PASSENGER')
	passengerBack.resetData()

	writer.save()


def printGraph():
	# Graph Printing
	plt.close("all")
	fig,axs = plt.subplots(2)

	driverFD = pd.read_excel(f"Vehicle_CSV.xlsx", sheet_name="FRONT DRIVER")
	driverFP = pd.read_excel(f"Vehicle_CSV.xlsx", sheet_name="FRONT PASSENGER")
	driverRD = pd.read_excel(f"Vehicle_CSV.xlsx", sheet_name="REAR DRIVER")
	driverRP = pd.read_excel(f"Vehicle_CSV.xlsx", sheet_name="REAR PASSENGER")
	#x = [0,1,2,3,4,5,6,7,8,9,10] Replacing X axis with dataFrame['TIME]
	axs[0].plot(driverFD['TIME'],driverFD['RPM'], label = 'FD RPM' )
	axs[0].plot(driverFP['TIME'],driverFP['RPM'], label = 'FP RPM' )
	axs[0].plot(driverRD['TIME'],driverRD['RPM'], label = 'RD RPM' )
	axs[0].plot(driverRP['TIME'],driverRP['RPM'], label = 'RP RPM' )
	# axs[0].xlabel("FRONT DRIVER SHOCK DISTANCE")
	# axs[0].ylabel("RPM")
	axs[0].legend()

	axs[1].plot(driverFD['TIME'],driverFD['SHOCK DISTANCE'], label = 'FD SHOCK DISTANCE' )
	axs[1].plot(driverFP['TIME'],driverFP['SHOCK DISTANCE'], label = 'FP SHOCK DISTANCE' )
	axs[1].plot(driverRD['TIME'],driverRD['SHOCK DISTANCE'], label = 'RD SHOCK DISTANCE' )
	axs[1].plot(driverRP['TIME'],driverRP['SHOCK DISTANCE'], label = 'RP SHOCK DISTANCE' )
	# axs[1].xlabel("FRONT DRIVER RPM")
	# axs[1].ylabel("SHOCK DISTANCE")
	axs[1].legend()

	# #--------------
	# ax = driverFD.plot(x="RPM", y="SHOCK DISTANCE")
	# ax = driverFP.plot(ax=ax,x="RPM",y="SHOCK DISTANCE")
	# # ax += driverRD.plot(ax=ax,x="TIME",y="SHOCK DISTANCE")
	# # driverRP.plot(ax=ax,x="TIME",y="SHOCK DISTANCE")
	# #--------------

	plt.savefig(f'Vehicle_Graph.pdf')
	#plt.show()


if __name__ == "__main__":
	main()
