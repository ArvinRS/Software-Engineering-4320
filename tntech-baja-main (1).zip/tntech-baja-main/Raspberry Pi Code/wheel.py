# 
#  File:     wheel.py 
#  Purpose:  Wheel object for suspension object
#  Date:     10/15/2022
#  Org:      Software Engineering Baja Team
#  Author:   Logan Gillum
#  Ref:      serialCom.py
#       

import time
import serial
 
class wheel:
#-------------------------------------------Worker Functions-------------------------------------------

	def __init__(self):
		# Constructor that sets inital suspension settings
		self.timestamp = 0
		self.RPM = 0
		self.wheelData = []
		self.wheelDataTime = []


	def eventsPerTime(self, currentTime):
		# Wheel Object RPM Calculator
		# Calculates RPM based on time, sets new timestamp, and returns RPM
		self.RPM = (1 / (currentTime - self.timestamp)) * 60
		self.timestamp = currentTime

#-------------------------------------------Access Functions-------------------------------------------

	# Set RPM Variable
	def setRPM(self):
		self.eventsPerTime(time.time())

	# Get RPM Variable
	def getRPM(self):
		return self.RPM

	# Append RPM Variable
	def appendRPM(self):
		self.wheelData.append(self.getRPM())
		self.wheelDataTime.append(time.time())

	# Get Wheel Data
	def getRPMData(self):
		return self.wheelData
	
	def getRPMTime(self):
		return self.wheelDataTime

	def printRPM(self):
		print("\rWheel RPM [{0}]".format(self.RPM), sep='\n', end='\n', flush=True)

	def resetRPM(self):
		self.wheelData = []
		self.wheelDataTime = []

#------------------------------------------------------------------------------------------------------



# Driver Code Examples
#Rodger = Dog("pug")
#Rodger.setColor("brown")
#print(Rodger.getColor())
