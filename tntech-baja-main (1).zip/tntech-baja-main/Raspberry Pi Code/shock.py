# 
#  File:     shock.py
#  Purpose:  shock object for suspension object
#  Date:     10/15/2022
#  Org:      Software Engineering Baja Team
#  Author:   Logan Gillum, Paul Haines
#       

import serial

class shock:
#-------------------------------------------Worker Functions-------------------------------------------

	def __init__(self,shockVoltage):
		# Constructor 
		# Sets inital suspension settings
		self.rideHeight = shockVoltage
		self.distancefromZero = 0
		self.shockData = []
		self.shockDataTime = []

	#-------------------------------------------Access Functions-------------------------------------------

	# Set Shock Travel Variable
	def setDistance(self, shockVoltage):
		if shockVoltage == None:
			print(shockVoltage)
		else:
			self.distancefromZero = shockVoltage - self.rideHeight

	# Get Shock Travel Voltage
	def getVoltage(self):
		return self.distancefromZero

	# Get Shock Travel Variable in Millimeters.
	def getDistance(self):
		return self.distancefromZero / 5.115

	# Get Shock Travel Voltage
	def appendDistance(self):
		self.shockData.append(self.getDistance())
		self.shockDataTime.append(time.time())


	# Get Distance Data
	def getDistanceData(self):
		return self.shockData

	def getDistanceTime(self):
		return self.shockDataTime

	def printRideHeight(self):
		print("Ride height [{0}]".format(self.distancefromZero), sep='\n', end=' ', flush=True)

	def resetDistance(self):
		self.shockData = []
		self.shockDataTime = []

#------------------------------------------------------------------------------------------------------



# Driver Code Examples
#Rodger = Dog("pug")
#Rodger.setColor("brown")
#print(Rodger.getColor())
