# 
#  File:     suspension.py
#  Imports:  wheel.py | shock.py
#  Purpose:  Suspension Object for systemDriver
#  Date:     10/15/2022
#  Org:      Software Engineering Baja Team
#  Author:   Logan Gillum
#       

import serial
from wheel import wheel
from shock import shock

class suspension:

#-------------------------------------------Worker Functions-------------------------------------------

	def __init__(self, name, shockVoltage):
		# Constructor that sets inital suspension settings
		self.name = name
		self.shockSensor = shock(shockVoltage)
		self.wheelSensor = wheel()

	def __str__(self):
		#String Name
		#Returns the name of the suspension
		return self.name

#-------------------------------------------Access Functions-------------------------------------------

	def printSuspensionStats(self):
		#Print Function
		#Prints Suspension details with loop for reading clarity.
		print(self, ": ")
		self.wheelSensor.printRPM()
		self.shockSensor.printRideHeight()

	def appendData(self):
		self.shockSensor.appendDistance()
		self.wheelSensor.appendRPM()

	def resetData(self):
		self.shockSensor.resetDistance()
		self.wheelSensor.resetRPM()

#------------------------------------------------------------------------------------------------------



# Driver Code Examples
#Rodger = Dog("pug")
#Rodger.setColor("brown")
#print(Rodger.getColor())

#Rodger = Kennel(`Holder of Dog Class`)
#Rodger.Dog.setColor("Brown")
#print(Rodger.Dog.getColor())
